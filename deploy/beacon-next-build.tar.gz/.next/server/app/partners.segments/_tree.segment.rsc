:HL["/_next/static/css/275ff7878ae809a3.css","style"]
:HL["/_next/static/css/03c72b32bc06a0d0.css","style"]
:HL["/_next/static/css/e854b521ccd3cf91.css","style"]
:HL["/whatsapp.svg","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"partners","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"UjN7cuaMoWNoOFcKWb0C0"}
